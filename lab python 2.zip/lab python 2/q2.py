
n = float (input ("Enter the number: "))

if n > 0:

              print ("The number provided is positive")

elif n == 0:          

              print ("The number input is zero")

else:

              print ("The number provided is negative")

